/**
 * Potch Connected - YouTube & YouTube Music Queue Integration
 * Extracts queue items from music.youtube.com and youtube.com and relays to Potch.
 */

(function () {
  const isYTMusic = location.hostname.includes("music.youtube.com");
  console.log(`[Potch] YouTube queue detector loaded (${isYTMusic ? "YT Music" : "YouTube"})`);

  function readQueue() {
    let items = [];
    let source = isYTMusic ? "YouTube Music" : "YouTube";

    if (isYTMusic) {
      const queueElements = document.querySelectorAll("ytmusic-player-queue-item");
      queueElements.forEach((el, index) => {
        const title = el.querySelector(".song-title")?.innerText?.trim();
        const artist = el.querySelector(".byline")?.innerText?.trim();
        const duration = el.querySelector(".duration")?.innerText?.trim();
        const thumb = el.querySelector("img")?.src;
        const isSelected = el.hasAttribute("selected");

        if (title) {
          items.push({
            index,
            i: index,
            title,
            artist: artist || "Unknown",
            duration: duration || "--:--",
            thumb: thumb || "",
            isSelected
          });
        }
      });
    } else {
      // Regular YouTube Playlist or Watch Queue
      const playlistElements = document.querySelectorAll("ytd-playlist-panel-video-renderer");
      if (playlistElements && playlistElements.length > 0) {
        playlistElements.forEach((el, index) => {
          const title = el.querySelector("#video-title")?.innerText?.trim() || el.querySelector("span#video-title")?.innerText?.trim();
          const artist = el.querySelector("#byline")?.innerText?.trim() || el.querySelector(".ytd-channel-name")?.innerText?.trim();
          const duration = el.querySelector("#length")?.innerText?.trim() || el.querySelector(".ytd-thumbnail-overlay-time-status-renderer")?.innerText?.trim();
          const thumb = el.querySelector("img")?.src;
          const isSelected = el.hasAttribute("selected");

          if (title) {
            items.push({
              index,
              i: index,
              title,
              artist: artist || "Unknown",
              duration: duration || "--:--",
              thumb: thumb || "",
              isSelected
            });
          }
        });
      } else {
        // Fallback: Up Next recommended items
        const compactElements = document.querySelectorAll("ytd-compact-video-renderer");
        compactElements.forEach((el, index) => {
          const title = el.querySelector("#video-title")?.innerText?.trim();
          const artist = el.querySelector(".ytd-channel-name")?.innerText?.trim();
          const duration = el.querySelector(".ytd-thumbnail-overlay-time-status-renderer")?.innerText?.trim();
          const thumb = el.querySelector("img")?.src;

          if (title) {
            items.push({
              index,
              i: index,
              title,
              artist: artist || "Unknown",
              duration: duration || "--:--",
              thumb: thumb || "",
              isSelected: index === 0
            });
          }
        });
      }
    }

    {
      const selectedIndex = items.findIndex(it => it.isSelected);
      chrome.runtime.sendMessage({
        type: "ytMusicQueue",
        source: source,
        cur: selectedIndex >= 0 ? selectedIndex : 0,
        items: items.slice(0, 30) // Up to 30 songs in queue
      });
    }
  }

  // Handle play action from Potch
  chrome.runtime.onMessage.addListener((msg) => {
    if ((msg.action === "playQueueIndex" || msg.action === "playRow") && Number.isInteger(msg.index) && msg.index >= 0) {
      if (isYTMusic) {
        const queueElements = document.querySelectorAll("ytmusic-player-queue-item");
        if (queueElements[msg.index]) {
          queueElements[msg.index].click();
        }
      } else {
        const playlistElements = document.querySelectorAll("ytd-playlist-panel-video-renderer");
        if (playlistElements[msg.index]) {
          const link = playlistElements[msg.index].querySelector("a#wc-endpoint") || playlistElements[msg.index].querySelector("a");
          if (link) link.click();
          else playlistElements[msg.index].click();
        }
      }
    }
  });

  // Periodic poll & observer
  readQueue();
  setInterval(readQueue, 3000);
})();
