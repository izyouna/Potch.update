/**
 * Potch Connected - Messenger & Instagram Web Call Detector
 * Detects incoming call dialogs via DOM MutationObserver and relays actions.
 */

(function () {
  console.log("[Potch] Messenger/Instagram call detector loaded on", window.location.hostname);

  let activeCallDetected = false;
  let activeCallId = null;
  const isInstagram = window.location.hostname.includes("instagram.com");
  const platform = isInstagram ? "Instagram" : "Messenger";

  function checkForIncomingCall() {
    // Selectors for Messenger & Instagram incoming call modals
    const callDialog = document.querySelector(
      '[aria-label*="Incoming call"], [aria-label*="สายเรียกเข้า"], [role="dialog"][aria-label*="call" i], div[data-testid="incoming_call_dialog"]'
    );

    if (callDialog && !activeCallDetected) {
      activeCallDetected = true;
      activeCallId = crypto.randomUUID();

      // Extract caller name
      let callerName = "Incoming Call";
      const nameEl = callDialog.querySelector('h1, h2, h3, [role="heading"], strong, span[dir="auto"]');
      if (nameEl && nameEl.innerText.trim()) {
        callerName = nameEl.innerText.trim();
      }

      // Check if video call
      const isVideo = !!callDialog.querySelector('svg[aria-label*="video" i], [aria-label*="กล้อง" i]');

      // Extract avatar
      const imgEl = callDialog.querySelector('img[src*="fbcdn"], img[src*="cdninstagram"]');
      const avatar = imgEl ? imgEl.src : null;

      console.log(`[Potch] Detected incoming ${platform} call from:`, callerName);

      chrome.runtime.sendMessage({
        type: "incomingCall",
        id: activeCallId,
        caller: callerName,
        platform: platform,
        isVideo: isVideo,
        avatar: avatar
      });
    } else if (!callDialog && activeCallDetected) {
      activeCallDetected = false;
      chrome.runtime.sendMessage({ type: "callEnded", id: activeCallId });
      activeCallId = null;
    }
  }

  // Observe DOM for incoming call popups
  const observer = new MutationObserver(() => {
    checkForIncomingCall();
  });

  checkForIncomingCall();
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true
  });

  // Listen for Accept / Decline commands from Potch
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (!activeCallDetected || message.callId !== activeCallId) { respond({ok: false}); return; }
    const dialog = document.querySelector('[aria-label*="Incoming call"], [aria-label*="สายเรียกเข้า"], [role="dialog"][aria-label*="call" i], div[data-testid="incoming_call_dialog"]');
    if (!dialog) { respond({ok: false}); return; }
    if (message.action === "accept") {
      const acceptBtn = dialog.querySelector(
        '[aria-label*="Answer" i], [aria-label*="รับสาย"], [aria-label*="Accept" i], button[color="primary"]'
      );
      if (acceptBtn) {
        console.log("[Potch] Clicking accept call button");
        acceptBtn.click();
        respond({ok: true});
      } else { respond({ok: false}); }
    } else if (message.action === "decline") {
      const declineBtn = dialog.querySelector(
        '[aria-label*="Decline" i], [aria-label*="ตัดสาย"], [aria-label*="Reject" i], button[color="negative"]'
      );
      if (declineBtn) {
        console.log("[Potch] Clicking decline call button");
        declineBtn.click();
        respond({ok: true});
      } else { respond({ok: false}); }
    }
  });
})();
