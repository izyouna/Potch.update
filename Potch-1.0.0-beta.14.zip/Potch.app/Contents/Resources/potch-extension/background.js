/**
 * Potch Connected Extension - Background Service Worker
 * Manages native messaging connection with com.potch.callbridge
 * and routes download progress and web call events.
 */

const NATIVE_HOST = "com.potch.callbridge";
let nativePort = null;
const callTabs = new Map();
let queueTabId = null;
const bridgeId = crypto.randomUUID();

function connectNative() {
  if (nativePort) return;
  try {
    nativePort = chrome.runtime.connectNative(NATIVE_HOST);
    console.log("[Potch] Connected to Native Messaging Host:", NATIVE_HOST);

    nativePort.onMessage.addListener((msg) => {
      console.log("[Potch] Message from Potch:", msg);
      handleNativeResponse(msg);
    });

    nativePort.onDisconnect.addListener(() => {
      console.log("[Potch] Native port disconnected:", chrome.runtime.lastError?.message);
      nativePort = null;
      // Retry connection after 5 seconds
      setTimeout(connectNative, 5000);
    });
  } catch (err) {
    console.error("[Potch] Failed to connect native:", err);
  }
}

connectNative();

function sendToPotch(payload) {
  if (!nativePort) {
    connectNative();
  }
  if (nativePort) {
    try {
      nativePort.postMessage({...payload, bridgeId});
    } catch (err) {
      console.error("[Potch] Error posting to native:", err);
    }
  }
}

// Handle action responses coming back from Potch UI
function handleNativeResponse(response) {
  if (response.bridgeId && response.bridgeId !== bridgeId) return;
  const { action, callId, downloadId } = response;

  if (action === "accept" || action === "decline") {
    const tabId = callTabs.get(callId);
    if (Number.isInteger(tabId)) {
      chrome.tabs.sendMessage(tabId, { action, callId }, (result) => {
        const ok = !chrome.runtime.lastError && result?.ok === true;
        sendToPotch({type: "callActionResult", id: callId, commandId: response.commandId, ok});
      });
    } else {
      sendToPotch({type: "callActionResult", id: callId, commandId: response.commandId, ok: false});
    }
  } else if (action === "playQueueIndex" || action === "playRow") {
    if (Number.isInteger(queueTabId) && Number.isInteger(response.index) && response.index >= 0) {
      chrome.tabs.sendMessage(queueTabId, { action, index: response.index }, () => void chrome.runtime.lastError);
    }
  } else if (["pauseDownload", "resumeDownload", "cancelDownload"].includes(action)) {
    const id = Number(downloadId);
    if (!Number.isInteger(id) || id < 0 || downloadId == null) return;
    const operation = {pauseDownload: "pause", resumeDownload: "resume", cancelDownload: "cancel"}[action];
    chrome.downloads[operation](id, () => {
      const ok = !chrome.runtime.lastError;
      sendToPotch({type: "downloadActionResult", id: String(id), commandId: response.commandId, ok});
    });
  }
}

// MARK: - Download Progress Tracking
if (chrome.downloads) {
  chrome.downloads.onChanged.addListener((delta) => {
    chrome.downloads.search({ id: delta.id }, (items) => {
      if (!items || !items.length) return;
      const dl = items[0];

      let state = "in_progress";
      if (dl.state === "complete") state = "complete";
      if (dl.state === "interrupted") state = "cancelled";
      if (dl.paused) state = "paused";

      const fileName = dl.filename ? dl.filename.split("/").pop().split("\\").pop() : "File";

      sendToPotch({
        type: "downloadProgress",
        id: String(dl.id),
        fileName: fileName,
        bytesReceived: dl.bytesReceived || 0,
        totalBytes: dl.totalBytes || 0,
        speed: 0,
        state: state
      });
    });
  });
}

// MARK: - Content Script Message Relay
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!Number.isInteger(sender.tab?.id)) return;
  if (message.type === "incomingCall" && typeof message.id === "string") {
    callTabs.set(message.id, sender.tab.id);
  } else if (message.type === "callEnded" && typeof message.id === "string") {
    if (callTabs.get(message.id) !== sender.tab.id) return;
    callTabs.delete(message.id);
  } else if (message.type === "ytMusicQueue") {
    queueTabId = sender.tab.id;
  } else if (message.type !== "videoFrame") {
    return;
  }
  sendToPotch({...message, tabId: sender.tab.id});
  sendResponse({ok: true});
});

chrome.tabs.onRemoved.addListener((id) => {
  for (const [callId, tabId] of callTabs) {
    if (tabId === id) {
      sendToPotch({type: "callEnded", id: callId, tabId: id});
      callTabs.delete(callId);
    }
  }
  if (queueTabId === id) {
    queueTabId = null;
    sendToPotch({type: "ytMusicQueue", items: [], playing: false});
  }
});

// onChanged omits ordinary received-byte updates; poll active transfers for a live meter.
setInterval(() => {
  if (!nativePort || !chrome.downloads) return;
  chrome.downloads.search({state: "in_progress"}, (items) => {
    for (const dl of items || []) {
      sendToPotch({type: "downloadProgress", id: String(dl.id),
        fileName: (dl.filename || "File").split(/[\\/]/).pop(),
        bytesReceived: dl.bytesReceived || 0, totalBytes: dl.totalBytes || 0,
        speed: 0, state: dl.paused ? "paused" : "in_progress"});
    }
  });
}, 1000);
setInterval(() => sendToPotch({type: "heartbeat"}), 10000);
